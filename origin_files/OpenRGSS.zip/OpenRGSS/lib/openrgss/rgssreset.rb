# Exception class providing notifications for when the F12 key is pressed during game execution.
#
# Name changed from the hidden class Reset before RGSS2.

class RGSSReset < Exception

end