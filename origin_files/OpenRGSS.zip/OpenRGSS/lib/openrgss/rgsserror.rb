# An exception class providing notifications of RGSS internal errors.
#
# Generated when, for instance, trying to access Bitmap or Sprite class objects that have already been freed.

class RGSSError < StandardError

end